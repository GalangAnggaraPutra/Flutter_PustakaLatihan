import 'package:flutter/foundation.dart';
import '../models/buku.dart';
import '../services/api_service.dart';
import '../utils/constants.dart';

class BukuProvider with ChangeNotifier {
  final ApiService _apiService = ApiService();
  List<Buku> _bukuList = [];
  bool _isLoading = false;
  String _error = '';

  List<Buku> get bukuList => _bukuList;
  bool get isLoading => _isLoading;
  String get error => _error;

  Future<void> getAllBuku() async {
    _isLoading = true;
    _error = '';
    notifyListeners();

    try {
      final response = await _apiService.get('${Constants.bukuEndpoint}/read.php');
      _bukuList = (response as List).map((item) => Buku.fromJson(item)).toList();
    } catch (e) {
      _error = 'Gagal mengambil data buku: $e';
    }

    _isLoading = false;
    notifyListeners();
  }

  Future<bool> addBuku(Buku buku) async {
    _isLoading = true;
    notifyListeners();

    try {
      final response = await _apiService.post(
        '${Constants.bukuEndpoint}/create.php',
        buku.toJson(),
      );
      
      if (response['success'] == true) {
        await getAllBuku();
        return true;
      }
      _error = response['message'] ?? 'Gagal menambah buku';
      return false;
    } catch (e) {
      _error = 'Gagal menambah buku: $e';
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }
}