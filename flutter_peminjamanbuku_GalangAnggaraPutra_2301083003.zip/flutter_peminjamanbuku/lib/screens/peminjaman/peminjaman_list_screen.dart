import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../providers/peminjaman_provider.dart';
import '../../models/peminjaman.dart';

class PeminjamanListScreen extends StatefulWidget {
  const PeminjamanListScreen({Key? key}) : super(key: key);

  @override
  State<PeminjamanListScreen> createState() => _PeminjamanListScreenState();
}

class _PeminjamanListScreenState extends State<PeminjamanListScreen> {
  @override
  void initState() {
    super.initState();
    Future.microtask(() =>
        Provider.of<PeminjamanProvider>(context, listen: false).getAllPeminjaman());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Daftar Peminjaman'),
      ),
      body: Consumer<PeminjamanProvider>(
        builder: (context, provider, child) {
          if (provider.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }

          if (provider.error.isNotEmpty) {
            return Center(child: Text(provider.error));
          }

          if (provider.peminjamanList.isEmpty) {
            return const Center(child: Text('Tidak ada data peminjaman'));
          }

          return ListView.builder(
            itemCount: provider.peminjamanList.length,
            itemBuilder: (context, index) {
              final peminjaman = provider.peminjamanList[index];
              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                child: ListTile(
                  title: Text('ID Anggota: ${peminjaman.anggota}'),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('ID Buku: ${peminjaman.buku}'),
                      Text('Tanggal Pinjam: ${DateFormat('dd/MM/yyyy').format(peminjaman.tanggalPinjam)}'),
                      if (peminjaman.tanggalKembali != null)
                        Text('Tanggal Kembali: ${DateFormat('dd/MM/yyyy').format(peminjaman.tanggalKembali!)}'),
                    ],
                  ),
                  trailing: peminjaman.tanggalKembali == null
                      ? ElevatedButton(
                          onPressed: () => _prosesKembali(context, peminjaman),
                          child: const Text('Kembalikan'),
                        )
                      : const Icon(Icons.check_circle, color: Colors.green),
                  onTap: () => _showPeminjamanDetail(context, peminjaman),
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _addPeminjaman(context),
        child: const Icon(Icons.add),
      ),
    );
  }

  void _addPeminjaman(BuildContext context) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const PeminjamanFormScreen()),
    );

    if (result == true) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Peminjaman berhasil ditambahkan')),
      );
    }
  }

  void _prosesKembali(BuildContext context, Peminjaman peminjaman) async {
    Navigator.pushNamed(context, '/pengembalian/form', arguments: peminjaman);
  }

  void _showPeminjamanDetail(BuildContext context, Peminjaman peminjaman) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => PeminjamanDetailScreen(peminjaman: peminjaman),
      ),
    );
  }
}