import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../models/pengembalian.dart';

class PengembalianDetailScreen extends StatelessWidget {
  final Pengembalian pengembalian;

  const PengembalianDetailScreen({
    Key? key, 
    required this.pengembalian,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Detail Pengembalian'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildDetailItem('ID Pengembalian', '${pengembalian.id}'),
                    _buildDetailItem('ID Peminjaman', '${pengembalian.peminjaman}'),
                    _buildDetailItem(
                      'Tanggal Dikembalikan',
                      DateFormat('dd MMMM yyyy').format(pengembalian.tanggalDikembalikan),
                    ),
                    _buildDetailItem('Terlambat', '${pengembalian.terlambat} hari'),
                    _buildDetailItem(
                      'Denda',
                      'Rp ${NumberFormat('#,###').format(pengembalian.denda)}',
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailItem(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 140,
            child: Text(
              label,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          ),
          Expanded(child: Text(value)),
        ],
      ),
    );
  }
}