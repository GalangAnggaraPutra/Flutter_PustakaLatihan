import 'package:flutter/foundation.dart';
import '../models/pengembalian.dart';
import '../services/api_service.dart';
import '../utils/constants.dart';

class PengembalianProvider with ChangeNotifier {
  final ApiService _apiService = ApiService();
  List<Pengembalian> _pengembalianList = [];
  bool _isLoading = false;
  String _error = '';

  List<Pengembalian> get pengembalianList => _pengembalianList;
  bool get isLoading => _isLoading;
  String get error => _error;

  Future<void> getAllPengembalian() async {
    _isLoading = true;
    _error = '';
    notifyListeners();

    try {
      final response = await _apiService.get('${Constants.pengembalianEndpoint}/read.php');
      _pengembalianList = (response as List).map((item) => Pengembalian.fromJson(item)).toList();
    } catch (e) {
      _error = 'Gagal mengambil data pengembalian: $e';
    }

    _isLoading = false;
    notifyListeners();
  }

  Future<bool> addPengembalian(Pengembalian pengembalian) async {
    _isLoading = true;
    notifyListeners();

    try {
      final response = await _apiService.post(
        '${Constants.pengembalianEndpoint}/create.php',
        pengembalian.toJson(),
      );
      
      if (response['success'] == true) {
        await getAllPengembalian();
        return true;
      }
      _error = response['message'] ?? 'Gagal menambah pengembalian';
      return false;
    } catch (e) {
      _error = 'Gagal menambah pengembalian: $e';
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  double hitungDenda(DateTime tanggalPinjam, DateTime tanggalKembali) {
    final selisihHari = tanggalKembali.difference(tanggalPinjam).inDays;
    if (selisihHari > 7) {
      return (selisihHari - 7) * 1000.0;
    }
    return 0.0;
  }
}