class Pengembalian {
  final int? id;
  final DateTime tanggalDikembalikan;
  final int terlambat;
  final double denda;
  final int peminjaman;
  final String? namaAnggota;
  final String? judulBuku;
  final DateTime? tanggalPinjam;

  Pengembalian({
    this.id,
    required this.tanggalDikembalikan,
    required this.terlambat,
    required this.denda,
    required this.peminjaman,
    this.namaAnggota,
    this.judulBuku,
    this.tanggalPinjam,
  });

  factory Pengembalian.fromJson(Map<String, dynamic> json) {
    return Pengembalian(
      id: int.parse(json['id'].toString()),
      tanggalDikembalikan: DateTime.parse(json['tanggal_dikembalikan']),
      terlambat: int.parse(json['terlambat'].toString()),
      denda: double.parse(json['denda'].toString()),
      peminjaman: int.parse(json['peminjaman'].toString()),
      namaAnggota: json['nama_anggota'],
      judulBuku: json['judul_buku'],
      tanggalPinjam: json['tanggal_pinjam'] != null 
          ? DateTime.parse(json['tanggal_pinjam'])
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'tanggal_dikembalikan': tanggalDikembalikan.toIso8601String(),
      'terlambat': terlambat,
      'denda': denda,
      'peminjaman': peminjaman,
    };
  }
}