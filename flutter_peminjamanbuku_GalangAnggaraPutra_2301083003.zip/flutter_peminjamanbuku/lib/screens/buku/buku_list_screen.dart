import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/buku_provider.dart';
import '../../models/buku.dart';
import 'buku_form_screen.dart';
import 'buku_detail_screen.dart';

class BukuListScreen extends StatefulWidget {
  const BukuListScreen({Key? key}) : super(key: key);

  @override
  State<BukuListScreen> createState() => _BukuListScreenState();
}

class _BukuListScreenState extends State<BukuListScreen> {
  @override
  void initState() {
    super.initState();
    Future.microtask(
      () => Provider.of<BukuProvider>(context, listen: false).getAllBuku(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Daftar Buku'),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () => _showSearchDialog(context),
          ),
        ],
      ),
      body: Consumer<BukuProvider>(
        builder: (context, provider, child) {
          if (provider.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }

          if (provider.error.isNotEmpty) {
            return Center(child: Text(provider.error));
          }

          if (provider.bukuList.isEmpty) {
            return const Center(child: Text('Tidak ada data buku'));
          }

          return ListView.builder(
            itemCount: provider.bukuList.length,
            itemBuilder: (context, index) {
              final buku = provider.bukuList[index];
              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                child: ListTile(
                  title: Text(buku.judul),
                  subtitle: Text('${buku.pengarang} (${buku.tahunTerbit})'),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.edit),
                        onPressed: () => _editBuku(context, buku),
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete),
                        onPressed: () => _deleteBuku(context, buku),
                      ),
                    ],
                  ),
                  onTap: () => _showBukuDetail(context, buku),
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _addBuku(context),
        child: const Icon(Icons.add),
      ),
    );
  }

  void _showSearchDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) {
        String searchQuery = '';
        return AlertDialog(
          title: const Text('Cari Buku'),
          content: TextField(
            onChanged: (value) => searchQuery = value,
            decoration: const InputDecoration(
              hintText: 'Masukkan judul atau pengarang',
              border: OutlineInputBorder(),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Batal'),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                if (searchQuery.isNotEmpty) {
                  Provider.of<BukuProvider>(context, listen: false)
                      .searchBuku(searchQuery);
                }
              },
              child: const Text('Cari'),
            ),
          ],
        );
      },
    );
  }

  void _addBuku(BuildContext context) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const BukuFormScreen()),
    );

    if (result == true) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Buku berhasil ditambahkan')),
      );
    }
  }

  void _editBuku(BuildContext context, Buku buku) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => BukuFormScreen(buku: buku),
      ),
    );

    if (result == true) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Buku berhasil diupdate')),
      );
    }
  }

  void _deleteBuku(BuildContext context, Buku buku) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Hapus Buku'),
        content: Text('Apakah Anda yakin ingin menghapus ${buku.judul}?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () async {
              Navigator.pop(context);
              final provider = Provider.of<BukuProvider>(context, listen: false);
              final success = await provider.deleteBuku(buku.id!);

              if (!mounted) return;
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(
                    success ? 'Buku berhasil dihapus' : 'Gagal menghapus buku',
                  ),
                ),
              );
            },
            child: const Text('Hapus'),
          ),
        ],
      ),
    );
  }

  void _showBukuDetail(BuildContext context, Buku buku) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => BukuDetailScreen(buku: buku),
      ),
    );
  }
}