class Constants {
  // Base URL untuk API
  static const String baseUrl = 'http://10.0.2.2/flutter_perpustakaan/api'; // untuk Android emulator
  // static const String baseUrl = 'http://localhost/flutter_perpustakaan/api'; // untuk web
  
  // Endpoints
  static const String anggotaEndpoint = '/anggota';
  static const String bukuEndpoint = '/buku';
  static const String peminjamanEndpoint = '/peminjaman';
  static const String pengembalianEndpoint = '/pengembalian';
}