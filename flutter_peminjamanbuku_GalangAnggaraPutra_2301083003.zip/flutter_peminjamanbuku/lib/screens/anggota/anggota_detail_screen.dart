import 'package:flutter/material.dart';
import '../../models/anggota.dart';

class AnggotaDetailScreen extends StatelessWidget {
  final Anggota anggota;

  const AnggotaDetailScreen({Key? key, required this.anggota}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Detail Anggota'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildDetailItem('NIM', anggota.nim.toString()),
            _buildDetailItem('Nama', anggota.nama),
            _buildDetailItem('Alamat', anggota.alamat),
            _buildDetailItem(
              'Jenis Kelamin',
              anggota.jenisKelamin == 'L' ? 'Laki-laki' : 'Perempuan',
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailItem(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            value,
            style: const TextStyle(fontSize: 16),
          ),
        ],
      ),
    );
  }
}