import 'package:flutter/foundation.dart';
import '../models/anggota.dart';
import '../services/api_service.dart';
import '../utils/constants.dart';

class AnggotaProvider with ChangeNotifier {
  final ApiService _apiService = ApiService();
  List<Anggota> _anggotaList = [];
  bool _isLoading = false;
  String _error = '';

  List<Anggota> get anggotaList => _anggotaList;
  bool get isLoading => _isLoading;
  String get error => _error;

  Future<void> getAllAnggota() async {
    _isLoading = true;
    _error = '';
    notifyListeners();

    try {
      final response = await _apiService.get('${Constants.anggotaEndpoint}/read.php');
      _anggotaList = (response as List).map((item) => Anggota.fromJson(item)).toList();
    } catch (e) {
      _error = 'Gagal mengambil data anggota: $e';
    }

    _isLoading = false;
    notifyListeners();
  }

  Future<bool> addAnggota(Anggota anggota) async {
    _isLoading = true;
    notifyListeners();

    try {
      final response = await _apiService.post(
        '${Constants.anggotaEndpoint}/create.php',
        anggota.toJson(),
      );
      
      if (response['success'] == true) {
        await getAllAnggota();
        return true;
      }
      _error = response['message'] ?? 'Gagal menambah anggota';
      return false;
    } catch (e) {
      _error = 'Gagal menambah anggota: $e';
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }
}