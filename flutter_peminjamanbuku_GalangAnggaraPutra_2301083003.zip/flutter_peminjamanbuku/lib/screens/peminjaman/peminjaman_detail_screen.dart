import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../models/peminjaman.dart';

class PeminjamanDetailScreen extends StatelessWidget {
  final Peminjaman peminjaman;

  const PeminjamanDetailScreen({
    Key? key, 
    required this.peminjaman,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Detail Peminjaman'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildDetailItem('ID Peminjaman', '${peminjaman.id}'),
                    _buildDetailItem('ID Anggota', '${peminjaman.anggota}'),
                    _buildDetailItem('ID Buku', '${peminjaman.buku}'),
                    _buildDetailItem(
                      'Tanggal Pinjam',
                      DateFormat('dd MMMM yyyy').format(peminjaman.tanggalPinjam),
                    ),
                    if (peminjaman.tanggalKembali != null)
                      _buildDetailItem(
                        'Tanggal Kembali',
                        DateFormat('dd MMMM yyyy').format(peminjaman.tanggalKembali!),
                      ),
                    _buildDetailItem(
                      'Status',
                      peminjaman.tanggalKembali == null ? 'Dipinjam' : 'Dikembalikan',
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailItem(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 120,
            child: Text(
              label,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          ),
          Expanded(child: Text(value)),
        ],
      ),
    );
  }
}