import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/anggota.dart';
import '../../providers/anggota_provider.dart';

class AnggotaFormScreen extends StatefulWidget {
  final Anggota? anggota;

  const AnggotaFormScreen({Key? key, this.anggota}) : super(key: key);

  @override
  State<AnggotaFormScreen> createState() => _AnggotaFormScreenState();
}

class _AnggotaFormScreenState extends State<AnggotaFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _nimController;
  late TextEditingController _namaController;
  late TextEditingController _alamatController;
  String _jenisKelamin = 'L';

  @override
  void initState() {
    super.initState();
    _nimController = TextEditingController(
        text: widget.anggota?.nim.toString() ?? '');
    _namaController = TextEditingController(
        text: widget.anggota?.nama ?? '');
    _alamatController = TextEditingController(
        text: widget.anggota?.alamat ?? '');
    _jenisKelamin = widget.anggota?.jenisKelamin ?? 'L';
  }

  @override
  void dispose() {
    _nimController.dispose();
    _namaController.dispose();
    _alamatController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.anggota == null
            ? 'Tambah Anggota'
            : 'Edit Anggota'),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextFormField(
              controller: _nimController,
              decoration: const InputDecoration(
                labelText: 'NIM',
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.number,
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'NIM tidak boleh kosong';
                }
                if (int.tryParse(value) == null) {
                  return 'NIM harus berupa angka';
                }
                return null;
              },
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _namaController,
              decoration: const InputDecoration(
                labelText: 'Nama',
                border: OutlineInputBorder(),
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Nama tidak boleh kosong';
                }
                return null;
              },
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _alamatController,
              decoration: const InputDecoration(
                labelText: 'Alamat',
                border: OutlineInputBorder(),
              ),
              maxLines: 3,
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Alamat tidak boleh kosong';
                }
                return null;
              },
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              value: _jenisKelamin,
              decoration: const InputDecoration(
                labelText: 'Jenis Kelamin',
                border: OutlineInputBorder(),
              ),
              items: const [
                DropdownMenuItem(value: 'L', child: Text('Laki-laki')),
                DropdownMenuItem(value: 'P', child: Text('Perempuan')),
              ],
              onChanged: (value) {
                setState(() {
                  _jenisKelamin = value!;
                });
              },
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: _saveAnggota,
              child: Text(
                widget.anggota == null ? 'Simpan' : 'Update',
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _saveAnggota() async {
    if (_formKey.currentState!.validate()) {
      final provider = Provider.of<AnggotaProvider>(context, listen: false);
      
      final anggota = Anggota(
        id: widget.anggota?.id,
        nim: int.parse(_nimController.text),
        nama: _namaController.text,
        alamat: _alamatController.text,
        jenisKelamin: _jenisKelamin,
      );

      bool success;
      if (widget.anggota == null) {
        success = await provider.addAnggota(anggota);
      } else {
        success = await provider.updateAnggota(anggota);
      }

      if (!mounted) return;
      if (success) {
        Navigator.pop(context, true);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(provider.error)),
        );
      }
    }
  }
}