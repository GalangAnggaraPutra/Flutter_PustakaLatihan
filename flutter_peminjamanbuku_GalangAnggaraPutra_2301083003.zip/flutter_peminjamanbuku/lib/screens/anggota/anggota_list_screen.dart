import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/anggota_provider.dart';
import '../../models/anggota.dart';
import 'anggota_form_screen.dart';
import 'anggota_detail_screen.dart';

class AnggotaListScreen extends StatefulWidget {
  const AnggotaListScreen({Key? key}) : super(key: key);

  @override
  State<AnggotaListScreen> createState() => _AnggotaListScreenState();
}

class _AnggotaListScreenState extends State<AnggotaListScreen> {
  @override
  void initState() {
    super.initState();
    Future.microtask(() =>
        Provider.of<AnggotaProvider>(context, listen: false).getAllAnggota());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Daftar Anggota'),
      ),
      body: Consumer<AnggotaProvider>(
        builder: (context, provider, child) {
          if (provider.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }

          if (provider.error.isNotEmpty) {
            return Center(child: Text(provider.error));
          }

          if (provider.anggotaList.isEmpty) {
            return const Center(child: Text('Tidak ada data anggota'));
          }

          return ListView.builder(
            itemCount: provider.anggotaList.length,
            itemBuilder: (context, index) {
              final anggota = provider.anggotaList[index];
              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                child: ListTile(
                  title: Text(anggota.nama),
                  subtitle: Text('NIM: ${anggota.nim}'),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.edit),
                        onPressed: () => _editAnggota(context, anggota),
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete),
                        onPressed: () => _deleteAnggota(context, anggota),
                      ),
                    ],
                  ),
                  onTap: () => _showAnggotaDetail(context, anggota),
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _addAnggota(context),
        child: const Icon(Icons.add),
      ),
    );
  }

  void _addAnggota(BuildContext context) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const AnggotaFormScreen()),
    );

    if (result == true) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Anggota berhasil ditambahkan')),
      );
    }
  }

  void _editAnggota(BuildContext context, Anggota anggota) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AnggotaFormScreen(anggota: anggota),
      ),
    );

    if (result == true) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Anggota berhasil diupdate')),
      );
    }
  }

  void _deleteAnggota(BuildContext context, Anggota anggota) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Hapus Anggota'),
        content: Text('Apakah Anda yakin ingin menghapus ${anggota.nama}?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () async {
              Navigator.pop(context);
              final provider =
                  Provider.of<AnggotaProvider>(context, listen: false);
              final success = await provider.deleteAnggota(anggota.id!);

              if (!mounted) return;
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(
                    success
                        ? 'Anggota berhasil dihapus'
                        : 'Gagal menghapus anggota',
                  ),
                ),
              );
            },
            child: const Text('Hapus'),
          ),
        ],
      ),
    );
  }

  void _showAnggotaDetail(BuildContext context, Anggota anggota) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AnggotaDetailScreen(anggota: anggota),
      ),
    );
  }
}