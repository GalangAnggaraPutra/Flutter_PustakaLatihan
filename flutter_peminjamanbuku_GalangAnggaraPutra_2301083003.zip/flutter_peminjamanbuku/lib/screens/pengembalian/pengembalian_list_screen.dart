import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../providers/pengembalian_provider.dart';
import '../../models/pengembalian.dart';

class PengembalianListScreen extends StatefulWidget {
  const PengembalianListScreen({Key? key}) : super(key: key);

  @override
  State<PengembalianListScreen> createState() => _PengembalianListScreenState();
}

class _PengembalianListScreenState extends State<PengembalianListScreen> {
  @override
  void initState() {
    super.initState();
    Future.microtask(() =>
        Provider.of<PengembalianProvider>(context, listen: false).getAllPengembalian());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Daftar Pengembalian'),
      ),
      body: Consumer<PengembalianProvider>(
        builder: (context, provider, child) {
          if (provider.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }

          if (provider.error.isNotEmpty) {
            return Center(child: Text(provider.error));
          }

          if (provider.pengembalianList.isEmpty) {
            return const Center(child: Text('Tidak ada data pengembalian'));
          }

          return ListView.builder(
            itemCount: provider.pengembalianList.length,
            itemBuilder: (context, index) {
              final pengembalian = provider.pengembalianList[index];
              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                child: ListTile(
                  title: Text('ID Peminjaman: ${pengembalian.peminjaman}'),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Tanggal Kembali: ${DateFormat('dd/MM/yyyy').format(pengembalian.tanggalDikembalikan)}'),
                      Text('Terlambat: ${pengembalian.terlambat} hari'),
                      Text('Denda: Rp ${NumberFormat('#,###').format(pengembalian.denda)}'),
                    ],
                  ),
                  onTap: () => _showPengembalianDetail(context, pengembalian),
                ),
              );
            },
          );
        },
      ),
    );
  }

  void _showPengembalianDetail(BuildContext context, Pengembalian pengembalian) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => PengembalianDetailScreen(pengembalian: pengembalian),
      ),
    );
  }
}