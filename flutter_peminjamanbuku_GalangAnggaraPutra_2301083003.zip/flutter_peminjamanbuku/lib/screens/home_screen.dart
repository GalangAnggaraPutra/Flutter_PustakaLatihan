// lib/screens/home_screen.dart
import 'package:flutter/material.dart';
import 'anggota/anggota_list.dart';
import 'buku/buku_list.dart';
import 'peminjaman/peminjaman_list.dart';
import 'pengembalian/pengembalian_list.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Perpustakaan'),
      ),
      body: GridView.count(
        padding: EdgeInsets.all(16),
        crossAxisCount: 2,
        children: [
          _buildMenuCard(
            context,
            'Anggota',
            Icons.people,
            () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => AnggotaListScreen()),
            ),
          ),
          _buildMenuCard(
            context,
            'Buku',
            Icons.book,
            () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => BukuListScreen()),
            ),
          ),
          _buildMenuCard(
            context,
            'Peminjaman',
            Icons.assignment_turned_in,
            () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => PeminjamanListScreen()),
            ),
          ),
          _buildMenuCard(
            context,
            'Pengembalian',
            Icons.assignment_return,
            () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => PengembalianListScreen()),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMenuCard(
    BuildContext context,
    String title,
    IconData icon,
    VoidCallback onTap,
  ) {
    return Card(
      elevation: 4,
      child: InkWell(
        onTap: onTap,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 48, color: Theme.of(context).primaryColor),
            SizedBox(height: 8),
            Text(
              title,
              style: Theme.of(context).textTheme.titleLarge,
            ),
          ],
        ),
      ),
    );
  }
}