import 'package:flutter/foundation.dart';
import '../models/peminjaman.dart';
import '../services/api_service.dart';
import '../utils/constants.dart';

class PeminjamanProvider with ChangeNotifier {
  final ApiService _apiService = ApiService();
  List<Peminjaman> _peminjamanList = [];
  bool _isLoading = false;
  String _error = '';

  List<Peminjaman> get peminjamanList => _peminjamanList;
  bool get isLoading => _isLoading;
  String get error => _error;

  Future<void> getAllPeminjaman() async {
    _isLoading = true;
    _error = '';
    notifyListeners();

    try {
      final response = await _apiService.get('${Constants.peminjamanEndpoint}/read.php');
      _peminjamanList = (response as List).map((item) => Peminjaman.fromJson(item)).toList();
    } catch (e) {
      _error = 'Gagal mengambil data peminjaman: $e';
    }

    _isLoading = false;
    notifyListeners();
  }

  Future<bool> addPeminjaman(Peminjaman peminjaman) async {
    _isLoading = true;
    notifyListeners();

    try {
      final response = await _apiService.post(
        '${Constants.peminjamanEndpoint}/create.php',
        peminjaman.toJson(),
      );
      
      if (response['success'] == true) {
        await getAllPeminjaman();
        return true;
      }
      _error = response['message'] ?? 'Gagal menambah peminjaman';
      return false;
    } catch (e) {
      _error = 'Gagal menambah peminjaman: $e';
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }
}