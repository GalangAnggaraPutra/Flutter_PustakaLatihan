import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../providers/peminjaman_provider.dart';
import '../../providers/anggota_provider.dart';
import '../../providers/buku_provider.dart';
import '../../models/peminjaman.dart';

class PeminjamanFormScreen extends StatefulWidget {
  const PeminjamanFormScreen({Key? key}) : super(key: key);

  @override
  State<PeminjamanFormScreen> createState() => _PeminjamanFormScreenState();
}

class _PeminjamanFormScreenState extends State<PeminjamanFormScreen> {
  final _formKey = GlobalKey<FormState>();
  DateTime _tanggalPinjam = DateTime.now();
  int? _selectedAnggota;
  int? _selectedBuku;

  @override
  void initState() {
    super.initState();
    Future.microtask(() {
      Provider.of<AnggotaProvider>(context, listen: false).getAllAnggota();
      Provider.of<BukuProvider>(context, listen: false).getAllBuku();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tambah Peminjaman'),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // Tanggal Pinjam
            InkWell(
              onTap: () => _selectDate(context),
              child: InputDecorator(
                decoration: const InputDecoration(
                  labelText: 'Tanggal Pinjam',
                  border: OutlineInputBorder(),
                ),
                child: Text(
                  DateFormat('dd/MM/yyyy').format(_tanggalPinjam),
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Pilih Anggota
            Consumer<AnggotaProvider>(
              builder: (context, anggotaProvider, child) {
                if (anggotaProvider.isLoading) {
                  return const CircularProgressIndicator();
                }
                return DropdownButtonFormField<int>(
                  value: _selectedAnggota,
                  decoration: const InputDecoration(
                    labelText: 'Anggota',
                    border: OutlineInputBorder(),
                  ),
                  items: anggotaProvider.anggotaList.map((anggota) {
                    return DropdownMenuItem(
                      value: anggota.id,
                      child: Text('${anggota.nim} - ${anggota.nama}'),
                    );
                  }).toList(),
                  onChanged: (value) {
                    setState(() {
                      _selectedAnggota = value;
                    });
                  },
                  validator: (value) {
                    if (value == null) {
                      return 'Pilih anggota';
                    }
                    return null;
                  },
                );
              },
            ),
            const SizedBox(height: 16),

            // Pilih Buku
            Consumer<BukuProvider>(
              builder: (context, bukuProvider, child) {
                if (bukuProvider.isLoading) {
                  return const CircularProgressIndicator();
                }
                return DropdownButtonFormField<int>(
                  value: _selectedBuku,
                  decoration: const InputDecoration(
                    labelText: 'Buku',
                    border: OutlineInputBorder(),
                  ),
                  items: bukuProvider.bukuList.map((buku) {
                    return DropdownMenuItem(
                      value: buku.id,
                      child: Text(buku.judul),
                    );
                  }).toList(),
                  onChanged: (value) {
                    setState(() {
                      _selectedBuku = value;
                    });
                  },
                  validator: (value) {
                    if (value == null) {
                      return 'Pilih buku';
                    }
                    return null;
                  },
                );
              },
            ),
            const SizedBox(height: 24),

            ElevatedButton(
              onPressed: _savePeminjaman,
              child: const Text('Simpan'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _tanggalPinjam,
      firstDate: DateTime(2000),
      lastDate: DateTime.now(),
    );
    if (picked != null && picked != _tanggalPinjam) {
      setState(() {
        _tanggalPinjam = picked;
      });
    }
  }

  void _savePeminjaman() async {
    if (_formKey.currentState!.validate()) {
      final provider = Provider.of<PeminjamanProvider>(context, listen: false);
      
      final peminjaman = Peminjaman(
        tanggalPinjam: _tanggalPinjam,
        anggota: _selectedAnggota!,
        buku: _selectedBuku!,
      );

      final success = await provider.addPeminjaman(peminjaman);

      if (!mounted) return;
      if (success) {
        Navigator.pop(context, true);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(provider.error)),
        );
      }
    }
  }
}