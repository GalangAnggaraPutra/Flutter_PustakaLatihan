import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../providers/pengembalian_provider.dart';
import '../../models/peminjaman.dart';
import '../../models/pengembalian.dart';

class PengembalianFormScreen extends StatefulWidget {
  final Peminjaman peminjaman;

  const PengembalianFormScreen({Key? key, required this.peminjaman}) 
      : super(key: key);

  @override
  State<PengembalianFormScreen> createState() => _PengembalianFormScreenState();
}

class _PengembalianFormScreenState extends State<PengembalianFormScreen> {
  final _formKey = GlobalKey<FormState>();
  DateTime _tanggalKembali = DateTime.now();
  late int _terlambat;
  late double _denda;

  @override
  void initState() {
    super.initState();
    _hitungTerlambatDanDenda();
  }

  void _hitungTerlambatDanDenda() {
    final provider = Provider.of<PengembalianProvider>(context, listen: false);
    final selisihHari = _tanggalKembali.difference(widget.peminjaman.tanggalPinjam).inDays;
    _terlambat = selisihHari > 7 ? selisihHari - 7 : 0;
    _denda = provider.hitungDenda(widget.peminjaman.tanggalPinjam, _tanggalKembali);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Proses Pengembalian'),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // Info Peminjaman
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Peminjam: ${widget.peminjaman.namaAnggota}'),
                    Text('Buku: ${widget.peminjaman.judulBuku}'),
                    Text('Tanggal Pinjam: ${DateFormat('dd/MM/yyyy').format(widget.peminjaman.tanggalPinjam)}'),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Tanggal Kembali
            InkWell(
              onTap: () => _selectDate(context),
              child: InputDecorator(
                decoration: const InputDecoration(
                  labelText: 'Tanggal Kembali',
                  border: OutlineInputBorder(),
                ),
                child: Text(
                  DateFormat('dd/MM/yyyy').format(_tanggalKembali),
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Info Keterlambatan dan Denda
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Keterlambatan: $_terlambat hari'),
                    Text('Denda: Rp ${NumberFormat('#,###').format(_denda)}'),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),

            ElevatedButton(
              onPressed: _savepengembalian,
              child: const Text('Proses Pengembalian'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _tanggalKembali,
      firstDate: widget.peminjaman.tanggalPinjam,
      lastDate: DateTime.now(),
    );
    if (picked != null && picked != _tanggalKembali) {
      setState(() {
        _tanggalKembali = picked;
        _hitungTerlambatDanDenda();
      });
    }
  }

  void _savepengembalian() async {
    if (_formKey.currentState!.validate()) {
      final provider = Provider.of<PengembalianProvider>(context, listen: false);
      
      final pengembalian = Pengembalian(
        tanggalDikembalikan: _tanggalKembali,
        terlambat: _terlambat,
        denda: _denda,
        peminjaman: widget.peminjaman.id!,
      );

      final success = await provider.addPengembalian(pengembalian);

      if (!mounted) return;
      if (success) {
        Navigator.pop(context, true);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(provider.error)),
        );
      }
    }
  }
}